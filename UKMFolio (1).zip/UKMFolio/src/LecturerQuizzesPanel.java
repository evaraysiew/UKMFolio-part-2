import javax.swing.*;
import java.awt.*;

public class LecturerQuizzesPanel extends JPanel{

}
