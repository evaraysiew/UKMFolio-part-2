import javax.swing.*;
import java.awt.*;

public class StudentQuizzesPanel extends JPanel{

}
