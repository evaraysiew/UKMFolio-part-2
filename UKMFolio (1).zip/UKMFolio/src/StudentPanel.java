
public class StudentPanel extends RolePanel {
    public StudentPanel(MainFrame mainFrame, String role) {
        super(mainFrame, role);
    }
}